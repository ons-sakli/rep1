import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-inscription',
  templateUrl: './inscription.component.html',
  styleUrl: './inscription.component.css'
})
export class InscriptionComponent {
inscriptionForm : FormGroup ;
constructor(private formBuilder : FormBuilder){
  this.inscriptionForm=this.formBuilder.group({
    nom :['',Validators.required],
    prenom:['',Validators.required],
    email:['',[Validators.required,Validators.email]],
    motDepasse:['',[Validators.required,Validators.minLength(6)]],
    confirmationMotDePasse:['',Validators.required],
  },
  {
    validators: this.passwordMatchValidator // Validation personnalisée
  });
}

passwordMatchValidator(form: FormGroup) {
  const password = form.get('motDepasse')?.value;
  const confirmPassword = form.get('confirmationMotDePasse')?.value;

  return password === confirmPassword ? null : { passwordMismatch: true };

}


onSubmit(){
  if(this.inscriptionForm.valid){
    console.log('données du formulaire d\'inscription:',this.inscriptionForm.value);
  }

    


  else {
    console.log('Le formulaire est invalide. Veuillez vérifier les champs.');

  }
}
}
