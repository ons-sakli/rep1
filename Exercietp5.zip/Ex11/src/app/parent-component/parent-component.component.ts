// parent-component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-parent-component',
  template: `<app-user-details [user]="selectedUser" (deleteUserEvent)="onDeleteUser()"></app-user-details>`,
  styles: []
})
export class ParentComponent {
  selectedUser: any = {
    name: 'ons sakli',
    email: 'onssk@gmail.com',
    
  };

  onDeleteUser() {
    console.log('Utilisateur supprimé');
  }
}
