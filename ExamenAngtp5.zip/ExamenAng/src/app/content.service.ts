
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ContentService {
  getOffres(): any[] {
    return [
      { id: 1, titre: 'Développeur Web', description: 'Description du poste de développeur web.' },
      { id: 2, titre: 'Designer UX/UI', description: 'Description du poste de designer UX/UI.' },
      {id : 3 , titre :'Ingenieur IT', description:'Description du pote d\'ingenieur IT'},
    ];
  }
}
