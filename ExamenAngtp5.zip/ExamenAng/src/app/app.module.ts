import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { HomeComponent } from './home/home.component';
import { EnvoyerCondidatureComponent } from './envoyer-condidature/envoyer-condidature.component';
import { ContactComponent } from './contact/contact.component';
import { ContentComponent } from './content/content.component';
import { FooterComponent } from './footer/footer.component';
import { OffreDescriptionComponent } from './offre-description/offre-description.component';
import { Routes ,RouterModule} from '@angular/router';

const routes: Routes = [
  { path: 'offres', component: ContentComponent },
  { path: 'offre/:id', component: OffreDescriptionComponent },
  { path: '', redirectTo: '/offres', pathMatch: 'full' },
];
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SideNavComponent,
    HomeComponent,
    EnvoyerCondidatureComponent,
    ContactComponent,
    ContentComponent,
    FooterComponent,
    OffreDescriptionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   RouterModule.forRoot(routes),
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
