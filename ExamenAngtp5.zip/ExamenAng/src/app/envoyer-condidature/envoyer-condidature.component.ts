import { Component } from '@angular/core';

@Component({
  selector: 'app-envoyer-condidature',
  templateUrl: './envoyer-condidature.component.html',
  styleUrl: './envoyer-condidature.component.css'
})
export class EnvoyerCondidatureComponent {

}
