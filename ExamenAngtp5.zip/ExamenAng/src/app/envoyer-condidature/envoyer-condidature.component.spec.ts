import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvoyerCondidatureComponent } from './envoyer-condidature.component';

describe('EnvoyerCondidatureComponent', () => {
  let component: EnvoyerCondidatureComponent;
  let fixture: ComponentFixture<EnvoyerCondidatureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EnvoyerCondidatureComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EnvoyerCondidatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
