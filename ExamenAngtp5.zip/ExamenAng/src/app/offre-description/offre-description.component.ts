import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-offre-description',
  templateUrl: './offre-description.component.html',
  styleUrl: './offre-description.component.css'
})
export class OffreDescriptionComponent {
  offreId:string | null | undefined;

  constructor(private route: ActivatedRoute) {
    this.offreId = this.route.snapshot.paramMap.get('id');
  }
}
