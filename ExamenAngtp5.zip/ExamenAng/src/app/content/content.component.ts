import { Component, OnInit } from '@angular/core';
import { ContentService } from '../content.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styles: [],
})
export class ContentComponent implements OnInit {
  offres: any[] = [];

  constructor(private contentService: ContentService) {}

  ngOnInit() {
    this.offres = this.contentService.getOffres();
  }
}
