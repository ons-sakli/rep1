import { CommonModule } from "@angular/common";
import { NewCompteComponent } from "../connexion.component";
import { LoginComponent } from "../login/login.component";
import { RouterModule } from "@angular/router";
import { AuthGuard } from "../auth-guard";
import { FilmsComponent } from "../../../films/films.component";
import { NgModule } from "@angular/core";
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';


@NgModule({
  declarations: [
    LoginComponent,
    NewCompteComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {path:'films',canActivate:[AuthGuard], component:FilmsComponent},
      {path:'login',component:LoginComponent},
      {path:'newcompte',component:NewCompteComponent}
  ]),  MatInputModule,
  MatButtonModule,
  MatFormFieldModule,
  MatCardModule,
  AngularFireModule.initializeApp(environment.firebase),
  AngularFireAuthModule,
  AngularFireStorageModule,
  ]
})
export class ConnexionModule { }