import { Component } from '@angular/core';

@Component({
  selector: 'app-new-compte',
  templateUrl: './new-compte.component.html',
  styleUrl: './new-compte.component.css'
})
export class NewCompteComponent {

}
